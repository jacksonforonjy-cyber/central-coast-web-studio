# Central Coast Web Studio — Universal Responsive Version

This is a single-file, fully responsive website that works on phone, tablet, and desktop.

Open `index.html` in a browser, or upload the folder to Vercel/Netlify.

Replace:
- hello@centralcoastwebstudio.com
- (805) 555-0124

Since you are under 18, use a parent/guardian for payment accounts, contracts, and client agreements.
